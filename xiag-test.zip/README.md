# xiag-test-001
xiag test problem

The thing operates on top of PHP + Redis. 
The php5-redis is used as a glue layer.

No frameworks were used, thus there's no sweet things like 
config files, flat dependency injection, and so forth; 
(almost) all values are hardcoded & so on.
CONNECTION PARAMS are hardcoded into RedisWrapperBasic class 
in DAL/RedisWrapper.php file. You'd want to set 'em up properly.



Redis databases used: 0,1,2,3.

initRedisDBs.php - would prepare redis databases for operation (flush & initialize).
test-addSomeUrls.php - would store couple of URLs & retrieve them back.

Regular operations, i.e. store Url / fetch Url are performed by IShortUrlsDal methods 
storeUrl and resolveToken correspondingly. Urls are stored for eternity, so there' 
no method for deleting one ;)

Maintenance is performed by IStorageMaintainer->performMaintenance()
(RedisStorageMaintainer is example implementation) and might be scheduled 
with cron, or be called within controller on demand.
Note that neither way is followed in prototype, the latter only performs maintenance
once in initRedisDBs.php - that's pretty enough for PoC.


Example of Run
$php -f initRedisDBs.php
...
DB Sizes
Pool: 7
Map: 0
Complete!
$php -f test-addSomeUrls.php
Original URLs:
http://www.bbc.com/travel/story/20141204-bbc-travels-2014-gift-guides
http://edition.cnn.com/2015/05/05/opinions/sutter-sea-level-climate/index.html
Tokens:
YYYYYYYYE
YYYYYYYYM
Fetched URLs:
http://www.bbc.com/travel/story/20141204-bbc-travels-2014-gift-guides
http://edition.cnn.com/2015/05/05/opinions/sutter-sea-level-climate/index.html
