<?php

/*
 * This would init redis databases for use with application
 *
 *  * CAUTION! *
 *  * All data might (and most likely will) be lost! *
 *
 * */
echo "...\n";

require_once "DAL/RedisWrapper.php";

$dal = new RedisWrapperBasic();
$dal->purgeMap();
$dal->purgePool();
$dal->purgeIntermediatePool();
$dal->initConfigDB();

require_once "UrlShortener/RedisStorageMaintainer.php";
require_once "UrlShortener/CustomBaseNumber.php";
require_once "UrlShortener/OrderedSetGenerator.php";
$t = new RedisStorageMaintainer(
    new CustomBaseNumber( (new OrderedSetGenerator())->getOrderedSet() ),
    new SimpleStringVerifier(),
    new RedisWrapperBasic()
);
$t->performMaintenance();

echo "DB Sizes\n";
echo "Pool: ". $dal->getPoolSize(). "\n";
echo "Map: ". $dal->getMapSize(). "\n";



echo "Complete!\n";
