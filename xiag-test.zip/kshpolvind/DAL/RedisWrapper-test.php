<?php


require_once "RedisWrapper.php";

$a = new RedisWrapperBasic();
//$a = new RedisWrapper();
//echo $a->getRedisInfo();
$a->purgeIntermediatePool();
$a->purgePool();
$a->purgeMap();
$a->purgeConf();
echo "Pools:\n";
$a->printIntermediatePool();
$a->printPool();
echo "Map:\n";
$a->printMap();
echo "Conf:\n";
$a->printConf();
$a->addToken('BzAP12LqL');
$a->addToken('oHcjpuLZu');
$a->addToken('cMunOb9cK');
$a->addToken('7gcTcwPD5');
$a->addToken('WZyBwEln1');
$a->addToken('WZyBwEln1');
$a->updatePool();
echo "-------------\n";
echo "Pools:\n";
$a->printIntermediatePool();
$a->printPool();
echo "Map:\n";
$a->printMap();
echo "-------------\n";
try {
    $result = $a->addUrl('http://www.youtube.com/watch?v=jGow4nmYkkA&index=22&list=RD0w_SnmVyksE', 'cMunOb9cK'); //var_dump($result); echo $a->getUrl('cMunOb9cK'). "\n";
//$result = $a->addUrl('http://www.youtube.com/watch?v=jGow4nmYkkA&index=22&list=RD0w_SnmVyksE', 'cMunOb9cK'); var_dump($result); echo $a->getUrl('cMunOb9cK'). "\n";
    $result = $a->addUrl('https://www.google.ru/webhp?sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8#q=phpredis'); //var_dump($result);
}
catch(RedisWrapperException $rwe){
//    throw $rwe;
}
echo "___________\n";
$a->printIntermediatePool();
$a->printPool();
$a->printMap();
$a->printConf();