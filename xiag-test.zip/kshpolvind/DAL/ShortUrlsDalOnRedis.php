<?php

require_once "RedisWrapper.php";


interface IShortUrlsDal{
    function resolveToken($tokenString);  // would resolve a short URL token, e.g. hlwqG6sh4 to  corresponding full URL
    function storeUrl($urlString);        // would get a token and bind it to the URL permanently
}

class ShortUrlsDalOnRedis {
    protected $redisWrapper = null;

    function __construct(){
        $this->redisWrapper = new RedisWrapper(); //Best injected with DI, yet not now
    }

    function resolveToken($tokenString){
        return $this->redisWrapper->getUrl($tokenString);
    }
    function storeUrl($urlString){
        $operationInfo = $this->redisWrapper->addUrl($urlString);
        return $operationInfo['token'];
    }
}