<?php


class RedisWrapperException extends Exception{}
class TokenNotFoundException extends RedisWrapperException{}
class RandomTokenNotObtainedException   extends RedisWrapperException{}
class PoolUpdateLockAlreadyObtained extends  RedisWrapperException{}
class PoolUpdateLockMustBeObtained extends  RedisWrapperException{}
class InvalidOperation  extends RedisWrapperException{}

interface IRedisWrapper
{
    function getUrl($token);
    function addUrl($url, $token = null);
    function getPoolSize();
    function addToken($token);
    function updatePool();
    function getMapSize();
    function purgeIntermediatePool();
    function purgePool();
    function purgeMap();
    function purgeConf();
    function getSeedToken();
    function obtainPoolUpdateLock();
    function releasePoolUpdateLock();
}

// for development & debug purpose
class RedisWrapperBasic implements IRedisWrapper{
    const ERRMSG_DOUBLE_POOL_LOCKING = '(): The instance tried to take already obtained lock for intermediate pool / redis db #';
    const ERRMSG_RANDOM_TOKEN_NOT_OBTAINED = "(): Cannot obtain random token from pool. Tokens Pool empty? \n";
    const ERRMSG_TOKEN_NOT_FOUND = "(): The \"%s\" token was not found. \n";
    const ERRMSG_POOL_UPDATE_IN_PROGRESS = "(): operation invalid when pool update locked. Pool update in progress?";
    const TOKEN_PREFIX = 'Token_';
    const POOL_UPDATE_LOCK = 'PoolUpdateLock';
    const LAST_ADDED_TOKEN = 'LastToken';

    protected $configDBNo = 0;
    protected $intermediatePoolDBNo = 1;
    protected $poolDBNo = 2;
    protected $mapDBNo = 3;
    protected $redisPass = 'mypass';
    protected $redis = null;
    protected $poolUpdateLock = null;



    protected function purgeDB($dbNo){
        if ($this->isPoolUpdateLocked()){
            throw new InvalidOperation(__METHOD__. self::ERRMSG_POOL_UPDATE_IN_PROGRESS);
        }
        else{
            $this->redis->select($dbNo);
            $this->redis->flushDB();
        }
    }
    protected function getDB($dbNo){
        $this->redis->select($dbNo);
        $tokens = $this->redis->keys('*');
        $result = [];
        foreach ($tokens as $token) {
            $result[$token] = $this->redis->get($token);
        }

        return $result;
    }
    protected function getDBCount($dbNo){
        $this->redis->select($dbNo);
        $result = $this->redis->dbSize();
        return $result;
    }
    function getRedisInfo(){
        $info = $this->redis->info();
        $result =
                    "[Introspection data] ".
                    "\nAddress: ". $this->redis->GetHost(). ":". $this->redis->GetPort().
                    "\nIsConnected: ". $this->redis->IsConnected().
                    "\nDB #: ". $this->redis->getDBNum().
                    "\nDB Size: ". $this->redis->dbSize().
                    "\nAuth: ". $this->redis->GetAuth().
                    "\n----------".
                    "\n PID: ". $info['process_id'].
                    "\n Config file: ". $info['config_file'].
                    "\n Server ver: ". $info['redis_version'].
                    "\n Role: ". $info['role'].
                    "\n Last save time: ". $info['rdb_last_save_time'].
                    "\n BGSave in progress: ". $info['rdb_bgsave_in_progress'].
                    "\n Changes since last save: ". $info['rdb_changes_since_last_save'].
                    "\n Clients connected: ". $info['connected_clients'].
                    "\n Used memory: ". $info['used_memory_human']. " (". $info['used_memory']. ")".
                    "\n";

        return $result;
    }

    function __construct(){
        $this->redis = new Redis();
//        $this->redis->pconnect('127.1');
        $this->redis->pconnect('192.168.104');
//        $this->redis->auth($this->redisPass);
    }
    function addToken($token){  // if not locked dismiss
        if($this->isPoolUpdateLockObtained()){
            $this->redis->select( $this->poolDBNo );
            $isExists = $this->redis->exists($token);
            $this->redis->select( $this->intermediatePoolDBNo );
            $isSet = ( $isExists ? false : $this->redis->setnx(self::TOKEN_PREFIX.$token, '') );
            if(!$isSet){
                return false;
            }
            else{
                $this->redis->set(self::LAST_ADDED_TOKEN, $token);
                return true;
            }
        }
        else{
            throw new PoolUpdateLockMustBeObtained();
        }
    }
    function getSeedToken(){
        $this->redis->select( $this->configDBNo );
        return $this->redis->get(self::LAST_ADDED_TOKEN);
    }
    function updatePool(){  // if not locked dismiss
        if($this->isPoolUpdateLockObtained()){
            $this->redis->select( $this->intermediatePoolDBNo );
            $tokens = $this->redis->keys(self::TOKEN_PREFIX.'*');   // scanning with limit + iteration over limited blocks would be better
            $result = [];
            foreach ($tokens as $token) {
                $token = mb_substr($token, mb_strlen(self::TOKEN_PREFIX));
                $tmp['0'] = $this->redis->renameKey(self::TOKEN_PREFIX.$token, $token);
                $tmp['1'] = $this->redis->move($token, $this->poolDBNo);
                $tmp['2'] = $this->redis->del($token);
                $result[$token] = $tmp;
            }
//            $this->redis->move(self::LAST_ADDED_TOKEN, $this->configDBNo);
            $lastAddedToken = $this->redis->get(self::LAST_ADDED_TOKEN);
            $this->redis->select($this->configDBNo);
            $this->redis->set(self::LAST_ADDED_TOKEN, $lastAddedToken);
            $this->redis->bgsave();
            $this->redis->bgrewriteaof();

            return $result;
        }
        else{
            throw new PoolUpdateLockMustBeObtained();
        }

    }
    function addUrl($url, $token=null){
        $this->redis->select($this->poolDBNo);
        if(is_null($token)){
            $token = $this->redis->randomKey();
            if($token===false){
                throw new RandomTokenNotObtainedException(__METHOD__. self::ERRMSG_RANDOM_TOKEN_NOT_OBTAINED . $this->getRedisInfo());
            }
        }
        else{
            if (!$this->redis->exists($token)){
                throw new TokenNotFoundException(__METHOD__.sprintf(self::ERRMSG_TOKEN_NOT_FOUND, $token). $this->getRedisInfo());
            }
        }
        $this->redis->watch($token);
        $result = $this->redis->multi()
            ->set($token, $url)
            ->move($token, $this->mapDBNo)
            ->delete($token)
            ->exec();
        $this->redis->unwatch();
        if($result===false){
            return false;
        }
        else{
            return ['token' => $token, 'set' => $result[0], 'copy' => $result[1], 'delete' => $result[2]];
        }
    }
    function getUrl($token){
        $this->redis->select( $this->mapDBNo );
        $result = $this->redis->get($token);
        if($result===false){
            throw new TokenNotFoundException(__METHOD__.sprintf(self::ERRMSG_TOKEN_NOT_FOUND, $token). $this->getRedisInfo());
        }
        else{
            return $result;
        }
    }
    // utility methods
    function getPoolSize(){ return $this->getDBCount($this->poolDBNo); }
//    function getIntemediatePoolSize(){}
    function getMapSize() { return $this->getDBCount($this->mapDBNo);}
    function purgeIntermediatePool(){ $this->purgeDB($this->intermediatePoolDBNo); }
    function purgePool(){ $this->purgeDB($this->poolDBNo); }
    function purgeMap() { $this->purgeDB($this->mapDBNo); }
    function purgeConf(){ $this->purgeDB($this->configDBNo); }
    // debug methods
    function printIntermediatePool(){ var_dump( $this->getDB($this->intermediatePoolDBNo) ); }
    function printConf(){ var_dump( $this->getDB($this->configDBNo)  ); }
    function printPool(){ var_dump( $this->getDB($this->poolDBNo) ); }
    // not to be used on prod
    function printMap() { var_dump( $this->getDB($this->mapDBNo)  ); }

    function initConfigDB(){
        $this->purgeConf();
        $this->redis->select($this->configDBNo);
        $this->redis->set(self::POOL_UPDATE_LOCK, '0');
        $this->redis->set(self::LAST_ADDED_TOKEN, '');
    }
    function isPoolUpdateLockObtained(){
        return ( !is_null($this->poolUpdateLock) );
    }
    function isPoolUpdateLocked(){
        $this->redis->select($this->configDBNo);
        return ( !$this->redis->get(self::POOL_UPDATE_LOCK)==='0' );
    }
    function obtainPoolUpdateLock(){
        if($this->isPoolUpdateLockObtained()){
            throw new PoolUpdateLockAlreadyObtained(__METHOD__. self::ERRMSG_DOUBLE_POOL_LOCKING .$this->intermediatePoolDBNo);
        }
        else{
            $result = null;
            $rnum = mt_rand(100000000, 999999999);
            $this->redis->select($this->configDBNo);
            if(!$this->isPoolUpdateLocked()){
                $this->redis->watch(self::POOL_UPDATE_LOCK);
                $isObtained = $this->redis->multi()
                    ->set(self::POOL_UPDATE_LOCK, $rnum)
                    ->exec();
                if($isObtained[0]===true){
                    $this->poolUpdateLock = $rnum;
                    $result = true;
                }
                else{
                    $result = false;
                }
            }
            else{
                $result = false;
            }

            return $result;
        }
    }
    function releasePoolUpdateLock(){
        $isFreed = null;
        $result = null;
        $this->redis->select($this->configDBNo);
        if ( $this->redis->get(self::POOL_UPDATE_LOCK) == $this->poolUpdateLock){
            $isFreed = $this->redis->set(self::POOL_UPDATE_LOCK, '0');
            if($isFreed===true){
                $this->poolUpdateLock = null;
                $result = true;
            }
            else{
                $result = false;
            }
        }

        return $result;
    }
}

// to be used on prod
class RedisWrapper extends RedisWrapperBasic implements IRedisWrapper
{
    function __construct(){
        parent::__construct();
    }
    function printMap(){
        return false;
    }
}