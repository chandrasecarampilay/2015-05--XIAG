<?php

require_once "DAL/ShortUrlsDalOnRedis.php";

$dal = new ShortUrlsDalOnRedis();


$bbcUrl = 'http://www.bbc.com/travel/story/20141204-bbc-travels-2014-gift-guides';
$cnnUrl = 'http://edition.cnn.com/2015/05/05/opinions/sutter-sea-level-climate/index.html';

$tokenForBBC = $dal->storeUrl($bbcUrl);
$tokenForCNN = $dal->storeUrl($cnnUrl);

echo "Original URLs:\n";
echo $bbcUrl. "\n";
echo $cnnUrl. "\n";

echo "Tokens:\n";
echo $tokenForBBC. "\n";
echo $tokenForCNN. "\n";

$fetchedBbcUrl = $dal->resolveToken($tokenForBBC);
$fetchedCnnUrl = $dal->resolveToken($tokenForCNN);

echo "Fetched URLs:\n";
echo $fetchedBbcUrl. "\n";
echo $fetchedCnnUrl. "\n";
