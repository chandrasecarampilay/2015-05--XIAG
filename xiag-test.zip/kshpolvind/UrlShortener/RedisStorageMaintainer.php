<?php

/*
 * TODO
 * Define namespaces
 * Implement autoloading feature
 *
 * */

interface IStorageMaintainer{
    function performMaintenance();
}

class RedisStorageMaintainer implements IStorageMaintainer{
    // reasonable for prod
//    protected $poolLowerThreshold = 300;
//    protected $poolUpperThreshold = 5000;
    // reasonable for PoC
    protected $poolLowerThreshold = 3;
    protected $poolUpperThreshold = 7;
    /**
     * @var ICustomBaseNumber
     */
    protected $customBaseNumber;
    /**
     * @var ISimpleStringVerifier
     */
    protected $stringVerifier;
    /**
     * @var IRedisWrapper
     */
    protected $serviceDal;

    protected function getNextToken(){
    }

    function __construct(ICustomBaseNumber $number, ISimpleStringVerifier $stringVerifier, IRedisWrapper $serviceDal){
        $this->customBaseNumber = $number;
        $this->stringVerifier = $stringVerifier;
        $this->serviceDal = $serviceDal;
    }

    protected function refillPool(){
        $max = $this->poolUpperThreshold;
        for($i=0; $i < $max; $i++){
            $newToken = $this->customBaseNumber->inc();
            // Here new token might be tested for validity
            if($this->stringVerifier->verifyString($newToken)){
                $this->serviceDal->addToken($newToken);
            }
            else{
                continue;
            }
        }
        $this->serviceDal->updatePool();
    }

    function performMaintenance(){
        if($this->serviceDal->obtainPoolUpdateLock()){
            if( $this->serviceDal->getPoolSize() < $this->poolLowerThreshold ){
                $seed = $this->serviceDal->getSeedToken();
                if($seed==''){
                    $this->customBaseNumber->initMinimalWithLength(9);
                }
                else{
                    $this->customBaseNumber->setValue($seed);
                }
                $this->refillPool();
                $this->serviceDal->releasePoolUpdateLock();
            }
        }
    }
}

// done
interface ISimpleStringVerifier{
    function verifyString($string);
}
// mvp done
class SimpleStringVerifier implements ISimpleStringVerifier{
    function verifyString($string)
    {
        // here, if required, goes check for string validity - readability, etc...
        // yet not in prototype
        return true;
    }
}
