<?php

interface IOrderedSetGenerator{
    function getOrderedSet();
}

class OrderedSetGenerator {
    private $orderedSet = array (
        0 => 'Y',
        1 => 'H',
        2 => 'K',
        3 => 'T',
        4 => 'E',
        5 => 'A',
        6 => 'M',
        7 => '7',
        8 => 'U',
        9 => 'x',
        10 => 'i',
        11 => 'o',
        12 => 'f',
        13 => '6',
        14 => 'v',
        15 => 'Q',
        16 => 'F',
        17 => '0',
        18 => 'L',
        19 => 's',
        20 => 'b',
        21 => 'D',
        22 => 'W',
        23 => 'n',
        24 => 'z',
        25 => 'S',
        26 => 'P',
        27 => 'R',
        28 => 'G',
        29 => 'X',
        30 => 'j',
        31 => 'p',
        32 => 'r',
        33 => 'g',
        34 => 'a',
        35 => 'Z',
        36 => 'I',
        37 => 'B',
        38 => 'O',
        39 => 'm',
        40 => 'c',
        41 => '3',
        42 => 'V',
        43 => '1',
        44 => '8',
        45 => 'y',
        46 => 'w',
        47 => '5',
        48 => 'N',
        49 => 'l',
        50 => 'e',
        51 => 't',
        52 => 'q',
        53 => '4',
        54 => 'k',
        55 => 'd',
        56 => 'C',
        57 => '2',
        58 => 'u',
        59 => 'h',
        60 => 'J',
        61 => '9',
    );

    function getOrderedSet(){
        return $this->orderedSet;
    }
}


/*
$arr =     array_values(
    array_merge(
        ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
        range('a','z'),
        range('A','Z')
    )
);
shuffle($arr);
var_export(
    $arr
);
*/