<?php

require_once "CustomBaseNumber.php";
require_once "OrderedSetGenerator.php";
require_once "../DAL/RedisWrapper.php";
require_once "RedisStorageMaintainer.php";
require_once "OrderedSetGenerator.php";


$r = new RedisWrapperBasic();
/*
//$r->purgeConf();
$r->initConfigDB();
$r->purgeIntermediatePool();
$r->purgePool();
$r->purgeMap();
$r->obtainPoolUpdateLock();
$r->addToken('BzAP12LqL');
//$r->addToken('YYYYYYYYY');
$r->updatePool();
$r->releasePoolUpdateLock();
echo "Pools:\n";
$r->printIntermediatePool();
$r->printPool();
$r->printMap();
$r->printConf();
*/

$t = new RedisStorageMaintainer(
                new CustomBaseNumber( (new OrderedSetGenerator())->getOrderedSet() ),
                new SimpleStringVerifier(),
                new RedisWrapperBasic()
);

$t->performMaintenance();


echo "Pools:\n";
$r->printIntermediatePool();
$r->printPool();
$r->printMap();
$r->printConf();



