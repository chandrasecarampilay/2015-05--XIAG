<?php

require_once "CustomBaseNumber.php";

$a = new CustomBaseNumber(
    array_values(
        array_merge(
            ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            range('a','z'),
            range('A','Z')
        )
    )
);

//var_dump($a);
$a->setValue('7gcTcwPD5');
var_dump($a->getValue());
$a->inc();
var_dump($a->getValue());

$a = new CustomBaseNumber(['B', '3', '0', '8', '1', 'c']);
$a->setValue('0000');
var_dump($a->getValue());
$a->inc();
var_dump($a->getValue());

