<?php


interface ICustomBaseNumber{
    function inc();
    function getValue();
    function getStringValue();
    function setValue($inputValue);
    function initMinimalWithLength($length=9);
}

class CustomBaseNumber implements ICustomBaseNumber{
    const INVALID_VALUE_PASSED = "(): invalid value passed ";
    const INVALID_PRESENTATION_VALUES_ARRAY_PASSED = "(): invalid presentation values array passed ";

    protected $presentation;
    protected $presentationReverse;
    protected $value = [];

    protected function parseFromString($str){
        preg_match_all('/./u', $str, $result);
        $result = array_reverse($result[0]);
        return $result;
    }
    protected function validateValue($inputValue){
        $result = true;
        if(!is_array($inputValue)){
            $result = false;
        }
        elseif(count($inputValue)==0){
            $result = false;
        }
        else{
            for($i=0;$i<count($inputValue);$i++){
                if (!isset($inputValue[$i])){
                    $result=false; break;
                }
                elseif( !in_array($inputValue[$i], $this->presentation) ){
                    $result=false; break;
                }
            }
        }
        return $result;
    }
    protected function validatePresentationValues($PresentationValues){
        $result = true;
        if(!is_array($PresentationValues)){
            $result = false;
        }
        elseif(count($PresentationValues)<2){
            $result = false;
        }
        elseif(array_values($PresentationValues)!==$PresentationValues){
            $result = false;
        }

        return $result;
    }

    public function __construct($orderedPresentationValues=['x','D','N'], $value = null){
        if( !$this->validatePresentationValues($orderedPresentationValues) ){
            throw new InvalidArgumentException(__METHOD__. self::INVALID_PRESENTATION_VALUES_ARRAY_PASSED);
        }
        $this->presentation = $orderedPresentationValues;
        $this->presentationReverse = array_flip($orderedPresentationValues);
        if( !is_null($value) ){
            $this->setValue($value);
        }
    }

    public function inc(){ // will not exceed length with carry, highest 'digit' would be lost instead
        $value =  $this->value;
        $max = count($this->presentation)-1;
        for($i=0; $i<count($value); $i++){
//        for($i=0; $i<9; $i++){
            if( $this->presentationReverse[$value[$i]] == $max ){
                $value[$i] = $this->presentation[0];
            }
            else{
                $value[$i] = $this->presentation[ 1 + $this->presentationReverse[$value[$i]] ];
                break;
            }
        }
        $this->value = $value;
        return $this->getStringValue();
    }

    /**
     * @return array
     */
    public function getValue()
    {
        return $this->value;
    }

    public function getStringValue(){
        $result = '';
        for($i=-1+count($this->value);$i>=0;$i--){
            $result .= $this->value[$i];
        }

        return $result;
    }
    /**
     * @param array $inputValue
     */
    public function setValue($inputValue)
    {
        if(is_string($inputValue)){
            $value = $this->parseFromString($inputValue);
        }
        else{
            $value = $inputValue;
        }
        if($this->validateValue($value)){
            $this->value = $value;
        }
        else{
            throw new InvalidArgumentException(__METHOD__. self::INVALID_VALUE_PASSED);
        }
    }

    public function initMinimalWithLength($length=9){
        $character = $this->presentation[0];
        $value = [];
        for($i=0; $i < $length; $i++){
            $value[$i] = $character;
        }
        $this->setValue($value);
    }

}